# Customer Segmentation Using Machine Learning

This project helps a retailer identify customer groups ("segments") using their transaction data. By analyzing what customers buy and their purchase patterns, we can group similar customers together.

# Objective

The goal is to create a clustering model that:
1. Finds overall buying patterns.
2. Groups customers based on the items they purchase.

We use K-Means Clustering, an Unsupervised Learning method, for this task.

# Dataset

The dataset, which contains past transaction details, is available in the `Files` folder.

# Implementation

The project is implemented in a Jupyter Notebook and includes:
1. Data analysis and cleaning.
2. Clustering using the K-Means algorithm.

